package com.bankproj;


import java.sql.*;


public class BankFinalProject {

    private static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:XE";
    private static final String USERNAME = "scott";
    private static final String PASSWORD = "tiger";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
            processTransactions(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void processTransactions(Connection connection) throws SQLException {
        // Fetch data from Transaction table
        String selectQuery = "SELECT TransID, AcctNo, OldBal, TransType, TransAmt, NewBal, TransStat FROM Transaction";
        try (Statement selectStatement = connection.createStatement();
             ResultSet resultSet = selectStatement.executeQuery(selectQuery)) {

            // Process each transaction
            while (resultSet.next()) {
                String transID = resultSet.getString("TransID");
                String transType = resultSet.getString("TransType");
                double transAmt = resultSet.getDouble("TransAmt");
                double oldBal = resultSet.getDouble("OldBal");
                double newBal = oldBal + (transType.equals("Deposit") ? transAmt : -transAmt);
                String transStat = newBal >= 0 ? "Valid" : "Invalid";
                System.out.println("\n Records Updated Successfully");
                // Update NewBal and TransStat in BankTrans table
                updateTransaction(connection, transID, newBal, transStat);

                // Log information into ValidTrans or InvalidTrans table
                logTransaction(connection, transID, transType, transAmt, transStat);
            }
        }
    }

    private static void updateTransaction(Connection connection, String transID, double newBal, String transStat)
            throws SQLException {
        String updateQuery = "UPDATE Transaction SET NewBal = ?, TransStat = ? WHERE TransID = ?";
        try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
            updateStatement.setDouble(1, newBal);
            updateStatement.setString(2, transStat);
            updateStatement.setString(3, transID);
            updateStatement.executeUpdate();
        }
    }

    private static void logTransaction(Connection connection, String transID, String transType, double transAmt,
                                       String validity) throws SQLException {
        String logTable = validity.equals("Valid") ? "ValidTrans" : "InvalidTrans";
        String insertQuery = "INSERT INTO " + logTable + "(TransID, TransType, TransAmt, ValidMessage) VALUES (?, ?, ?, ?)";
        try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
            insertStatement.setString(1, transID);
            insertStatement.setString(2, transType);
            insertStatement.setDouble(3, transAmt);
            insertStatement.setString(4, validity);
            insertStatement.executeUpdate();
        }
    }
}