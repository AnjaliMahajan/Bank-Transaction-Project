package com.bankproj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class jdcon{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try
	     {
		// Loading the Database Driver
		Class.forName("oracle.jdbc.driver.OracleDriver");

		// Establish the Connection
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "scott", "tiger");

		// Create the Statement
		Statement stmt = con.createStatement();

		// Execute the Statement and Returning ResultSet object
		ResultSet rs = stmt.executeQuery("SELECT TransId, Acctno, OldBal,Transtype,TransAmt,NewBal,TransStat FROM Transaction");

		//Retrieving the data returned by the Statement
	 
	   	while(rs.next())
	   	{

	   		
	   		String tTransId = rs.getString(1);	int tAcctno = rs.getInt(2);
			double tOldBal = rs.getDouble(3);	String tTransType = rs.getString(4);
			double tTransAmt = rs.getDouble(5); 
                        double tNewBal  = rs.getDouble(6);
                        String tTransStat = rs.getString(7);
	   		

			System.out.println(tTransId + "   " + tAcctno + "   " + tOldBal + "   " + tTransType+ "   " + tTransAmt+ "  " + tNewBal+ "  " + tTransStat);
	 
	   	}	
		
		con.close();
	     }
	     catch(Exception e)
	     {
		e.printStackTrace();
	     }


	}

}

